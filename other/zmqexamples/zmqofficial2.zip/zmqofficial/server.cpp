#include <zmq.hpp>
#include <iostream>
#include <chrono>
#include <thread>
#include "message.pb.h" // Replace with your generated protobuf header

int main() {
    using namespace std::chrono_literals;

    // Initialize the ZeroMQ context with a single IO thread
    zmq::context_t context{1};

    // Construct a PUB (Publisher) socket and bind to an interface
    zmq::socket_t socket{context, zmq::socket_type::push};
    socket.bind("udp://*:5555");
    int cnt = 0;

    // Create an instance of your Protobuf message
    PROTO::MyMessage response_message; // Replace with your actual message name and namespace

    while (true) {
        // Prepare a response
        response_message.set_name("Hello from Server!" + std::to_string(cnt));

        // Serialize the response message
        std::string serialized_response;
        response_message.SerializeToString(&serialized_response);

        // Send the reply to the client
        socket.send(zmq::buffer(serialized_response), zmq::send_flags::none);

        // Simulate work
        std::this_thread::sleep_for(1s);
        cnt++;
    }

    return 0;
}

