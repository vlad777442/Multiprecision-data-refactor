#include <zmq.hpp>
#include <iostream>
#include "message.pb.h" // Replace with your generated protobuf header

int main() {
    // Initialize the ZeroMQ context with a single IO thread
    zmq::context_t context{1};

    // Construct a SUB (Subscriber) socket and connect to the interface
    zmq::socket_t socket{context, zmq::socket_type::pull};
    socket.connect("tcp://localhost:5555");
    //socket.setsockopt(ZMQ_SUBSCRIBE, "", 0); // Subscribe to all messages
    int cnt = 0;

    while (true) {
        // Wait for reply from server
        zmq::message_t reply;
        (void)socket.recv(reply, zmq::recv_flags::none);

        // Deserialize the received message into the protobuf object
        PROTO::MyMessage received_response; // Replace with your actual message name and namespace
        received_response.ParseFromArray(reply.data(), reply.size());

        // Print received data
        std::cout << "Received: Message - " << received_response.name() << std::endl;
    }

    return 0;
}

