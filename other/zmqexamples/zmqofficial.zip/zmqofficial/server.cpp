#include <chrono>
#include <thread>
#include <iostream>

#include <zmq.hpp>
#include "message.pb.h"

int main() {
    using namespace std::chrono_literals;

    // initialize the ZeroMQ context with a single IO thread
    zmq::context_t context{1};

    // construct a REP (reply) socket and bind to interface
    zmq::socket_t socket{context, zmq::socket_type::rep};
    socket.bind("tcp://*:5555");

    // create an instance of your Protobuf message
    PROTO::MyMessage response_message; // Replace with your actual message name and namespace

    for (;;) {
        zmq::message_t received_message;

        // receive a request from the client
        (void)socket.recv(received_message, zmq::recv_flags::none);

        // Deserialize the received message into the protobuf object
        response_message.ParseFromArray(received_message.data(), received_message.size());
	
	std::cout << "Received Message:" << std::endl;
        std::cout << "ID: " << response_message.id() << std::endl;
        std::cout << "Name: " << response_message.name() << std::endl;
	
        // simulate work
        std::this_thread::sleep_for(1s);

        // prepare a response
        response_message.set_name("Hello from Server!");

        // Serialize the response message
        std::string serialized_response;
        response_message.SerializeToString(&serialized_response);

        // send the reply to the client
        socket.send(zmq::buffer(serialized_response), zmq::send_flags::none);
    }

    return 0;
}

