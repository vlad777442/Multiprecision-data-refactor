#include <iostream>
#include <zmq.hpp>
#include "message.pb.h" // Replace with your generated protobuf header

int main() {
    // initialize the ZeroMQ context with a single IO thread
    zmq::context_t context{1};

    // construct a REQ (request) socket and connect to the interface
    zmq::socket_t socket{context, zmq::socket_type::req};
    socket.connect("tcp://localhost:5555");

    // create an instance of your Protobuf message
    PROTO::MyMessage request_message; // Replace with your actual message name and namespace

    for (auto request_num = 0; request_num < 10; ++request_num) {
        // Set up data in the Protobuf message
        request_message.set_id(request_num);
        request_message.set_name("Hello from Client!");

        // Serialize the message
        std::string serialized_request;
        request_message.SerializeToString(&serialized_request);

        // send the request message
        socket.send(zmq::buffer(serialized_request), zmq::send_flags::none);
        
        // wait for reply from server
        zmq::message_t reply;
        (void)socket.recv(reply, zmq::recv_flags::none);

        // Deserialize the received message into the protobuf object
        PROTO::MyMessage received_response; // Replace with your actual message name and namespace
        received_response.ParseFromArray(reply.data(), reply.size());

        // Print received data
        std::cout << "Received: ID - " << received_response.id() << ", Message - " << received_response.name() << std::endl;
    }

    return 0;
}

